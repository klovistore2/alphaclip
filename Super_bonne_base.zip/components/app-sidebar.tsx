"use client"

import * as React from "react"
import {

  BookOpen,
  Pencil,
  ImagePlus,
  Frame,
  Video,
  Map,
  PieChart,

} from "lucide-react"

import { NavMain } from "@/components/nav-main"
//import { NavProjects } from "@/components/nav-projects"
import { NavUser } from "@/components/nav-user"
//import { TeamSwitcher } from "@/components/team-switcher"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarRail,
} from "@/components/ui/sidebar"

// This is sample data.
const data = {
  user: {
    name: "shadcn",
    email: "m@example.com",
    avatar: "/avatars/shadcn.jpg",
  },

  navMain: [
    {
      title: "Gallery",
      url: "#",
      icon: BookOpen,
      isActive: true,
      items: [
        {
          title: "Image",
          url: "#",
        },
        {
          title: "Video",
          url: "#",
        },
        {
          title: "Sound",
          url: "#",
        },
      ],
    },
    {
      title: "Create Image",
      url: "#",
      icon: Pencil,
      items: [
        {
          title: "Text to Image",
          url: "/dashboard//create//text2image",
        },
        {
          title: "Canva",
          url: "/dashboard//create//canva",
        },
        {
          title: "Uploads",
          url: "#",
        },
      ],
    },
    {
      title: "Image to Image",
      url: "#",
      icon: ImagePlus,
      items: [
        {
          title: "Upscaler",
          url: "/dashboard//image2image//upscaler/",
        },
        {
          title: "Inpainting",
          url: "/dashboard//image2image//inpainting/",
        },
        {
          title: "Remove Background",
          url: "#",
        },
        {
          title: "Image Variations",
          url: "#",
        },
      ],
    },
    {
      title: "Generate Video",
      url: "#",
      icon: Video,
      items: [
        {
          title: "Image to Video",
          url: "#",
        },
        {
          title: "Text to Video",
          url: "#",
        },
        {
          title: "-",
          url: "#",
        },
        {
          title: "-",
          url: "#",
        },
      ],
    },
  ],
  projects: [
    {
      name: "Design Engineering",
      url: "#",
      icon: Frame,
    },
    {
      name: "Sales & Marketing",
      url: "#",
      icon: PieChart,
    },
    {
      name: "Travel",
      url: "#",
      icon: Map,
    },
  ],
}
//<NavProjects projects={data.projects} />
export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  return (
    <Sidebar collapsible="icon" {...props}>
      <SidebarHeader>

      </SidebarHeader>
      <SidebarContent>
        <NavMain items={data.navMain} />
        

      </SidebarContent>
      <SidebarFooter>
        <NavUser user={data.user} />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
