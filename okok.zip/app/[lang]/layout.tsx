import { ThemeProvider } from "@/components/theme-provider"

export async function generateStaticParams() {
    return [{ lang: 'en' }, { lang: 'fr' }]
  }
   
export default async function RootLayout({
    children,
    params,
  }: Readonly<{
    children: React.ReactNode
    params: Promise<{ lang: 'en' | 'fr' }>
  }>) {
    return (
      <html lang={(await params).lang}>
        <body>
        <ThemeProvider
                      attribute="class"
                      defaultTheme="system"
                      enableSystem
                      disableTransitionOnChange
                  >
          {children}</ThemeProvider></body>
      </html>
    )
 }