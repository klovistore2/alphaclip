import { handlers } from "@/lib/auth" // Assurez-vous que le chemin vers auth.ts est correct
export const { GET, POST } = handlers