import { getDictionary } from './dictionaries'
 
export default async function Page({
  params,
}: {
  params: Promise<{ lang: 'en' | 'fr' }>
}) {
  
  const { lang } = await params
  
  const dict = await getDictionary(lang) // en

  return (
    <div>
      <h1>{dict.products.cart}</h1>
      <p>{dict.products.text}</p>
    </div>
  )
           // Add to Cart
} 