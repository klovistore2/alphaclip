import { Metadata } from "next"
import Image from "next/image"
import { Download, RotateCcw, Upload,  MoveHorizontal } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { ModelSelector } from "../components/model-selector"
import { PresetActions } from "../components/preset-actions"
import { PresetSelector } from "../components/preset-selector"
import { PresetShare } from "../components/preset-share"
import { models, types } from "../data/models"
import { presets } from "../data/presets"

import { getDictionary } from "@/app/[lang]/dictionaries" 

export const metadata: Metadata = {
  title: "Image-to-Image",
  description: "AI Image-to-Image Transformation Playground",
}


export default async function ImageToImagePlayground({
  params,
}: {
  params: Promise<{ lang: 'en' | 'fr'; image?: string }>
}) {
  const { lang, image } = await params;
  const imageParam = image || "default-image"; // Par exemple : "default-image"

  const dict = await getDictionary(lang); // Récupère le dictionnaire pour la langue
  console.log("Image param:", imageParam); // Debug : Affiche le paramètre image


  return (
    <>
      <div className="md:hidden">
        <p className="p-4 text-center">Please use a larger screen for the full Image-to-Image experience.</p>
      </div>
      <div className="hidden h-full flex-col md:flex">
        <div className="container flex flex-col items-start justify-between space-y-2 py-4 sm:flex-row sm:items-center sm:space-y-0 md:h-16">
          <h2 className="text-lg font-semibold">Image-to-Image Playground {dict.create_image.title}</h2>
          <div className="ml-auto flex w-full space-x-2 sm:justify-end">
            <PresetSelector presets={presets} />
            <div className="hidden space-x-2 md:flex">
              <PresetShare />
            </div>
            <PresetActions />
          </div>
        </div>
        <Separator />

        {/* Main Content */}
        <div className="container h-full py-6">
          {/* Two column layout for desktop: Top controls, bottom image comparison */}
          <div className="flex flex-col space-y-6">
            {/* Top Section - Controls */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Image Upload Section */}
              <Card className="col-span-1">
                <CardContent className="p-4 space-y-4">
                  <h3 className="text-lg font-medium">Source Image</h3>
                  <div className="flex flex-col space-y-2">
                    <Button className="w-full">
                      <Upload className="mr-2 h-4 w-4" />
                      Upload Image
                    </Button>
                    <p className="text-xs text-muted-foreground text-center">
                      Supports JPG, PNG, WebP (Max 4MB)
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Prompt Input */}
              <Card className="col-span-1 lg:col-span-2">
                <CardContent className="p-4 space-y-4">
                  <h3 className="text-lg font-medium">Transformation Prompt</h3>
                  <Textarea 
                    placeholder="Describe how you want to transform the source image..." 
                    className="min-h-[100px]"
                  />
                  <div className="flex justify-end">
                    <Button type="submit" className="w-full sm:w-auto">
                      Transform Image
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Model & Parameters Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="col-span-1">
                <ModelSelector types={types} models={models} />
              </div>

              {/* Transformation Strength */}
              <div className="col-span-1 space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="strength">Transformation Strength</Label>
                    <span className="text-sm text-muted-foreground">0.75</span>
                  </div>
                  <Slider
                    id="strength"
                    max={1}
                    step={0.05}
                    defaultValue={[0.75]}
                    className="[&_[role=slider]]:h-4 [&_[role=slider]]:w-4"
                  />
                  <p className="text-xs text-muted-foreground">
                    Higher values produce more dramatic changes
                  </p>
                </div>
              </div>

              {/* Steps */}
              <div className="col-span-1 space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="steps">Sampling Steps</Label>
                    <span className="text-sm text-muted-foreground">30</span>
                  </div>
                  <Slider
                    id="steps"
                    min={10}
                    max={50}
                    step={1}
                    defaultValue={[30]}
                    className="[&_[role=slider]]:h-4 [&_[role=slider]]:w-4"
                  />
                </div>
              </div>

              {/* Guidance Scale */}
              <div className="col-span-1 space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="guidance">Guidance Scale</Label>
                    <span className="text-sm text-muted-foreground">7.5</span>
                  </div>
                  <Slider
                    id="guidance"
                    min={1}
                    max={20}
                    step={0.5}
                    defaultValue={[7.5]}
                    className="[&_[role=slider]]:h-4 [&_[role=slider]]:w-4"
                  />
                </div>
              </div>
            </div>

            {/* Image Comparison Section - Before & After */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Source Image - Left */}
              <div className="flex flex-col space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Source Image</h3>
                </div>
                <Card className="border border-dashed flex items-center justify-center rounded-lg overflow-hidden aspect-square">
                  <CardContent className="p-0 w-full h-full flex items-center justify-center">
                    <div className="text-center p-6">
                      {/* Placeholder for source image */}
                      <div className="flex flex-col items-center justify-center h-full space-y-2">
                        <Image
                          src="/examples/placeholder-source.png" 
                          width={400}
                          height={400}
                          alt="Source image will appear here"
                          className="opacity-30"
                        />
                        <p className="text-sm text-muted-foreground">Upload your source image</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Result Image - Right */}
              <div className="flex flex-col space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Transformed Image</h3>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" disabled>
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                    <Button size="sm" variant="outline" disabled>
                      <RotateCcw className="mr-2 h-4 w-4" />
                      Regenerate
                    </Button>
                  </div>
                </div>
                <Card className="border border-dashed flex items-center justify-center rounded-lg overflow-hidden aspect-square">
                  <CardContent className="p-0 w-full h-full flex items-center justify-center">
                    <div className="text-center p-6">
                      {/* Placeholder for transformed image */}
                      <div className="flex flex-col items-center justify-center h-full space-y-2">
                        <Image
                          src="/examples/placeholder-result.png" 
                          width={400}
                          height={400}
                          alt="Transformed image will appear here"
                          className="opacity-30"
                        />
                        <p className="text-sm text-muted-foreground">Click Transform Image to start</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Comparison Tools */}
            <div className="flex items-center justify-center space-x-2">
              <Button variant="outline" disabled>
                <MoveHorizontal className="mr-2 h-4 w-4" />
                Side-by-Side Comparison
              </Button>
            </div>

            {/* Generation Parameters Display */}
            <Card>
              <CardContent className="p-4">
                <h3 className="text-sm font-medium mb-2">Last Generation Parameters</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs text-muted-foreground">
                  <div><strong>Model:</strong> Stable Diffusion XL</div>
                  <div><strong>Strength:</strong> 0.75</div>
                  <div><strong>Steps:</strong> 30</div>
                  <div><strong>CFG Scale:</strong> 7.5</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  )
}
